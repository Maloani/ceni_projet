﻿
 <?php 
	
	require_once ('include/connex.php'); 

 ?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="description" content="La vision de la Caritas Développement Bukavu est celle d’une communauté humaine solidaire, vivant dans la paix, capable de se prendre en charge et jouissant de toute sa dignité">
	<meta name="keywords" content="CENI BUKAVU - Accueil">
		
	<title>CENI BUKAVU - Accueil</title>
		
	
	<!--FAVICON -->
	<link rel="shortcut icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">
	<link rel="icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">

	<link href='css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-1?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-2?family=Oswald:400,700' rel='stylesheet' type='text/css'>
	<link href='css-3?family=Droid+Sans' rel='stylesheet' type='text/css'>
	
	<link rel="stylesheet" type="text/css" href="css-4?family=Convergence">

	<link rel="stylesheet" href="css%20%281%29/foundation.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/responsive.css" type="text/css" media="screen">
	
	
	<script type="text/javascript">
		var marge_x_rfi = (screen.width - 245) / 2
		var marge_y_rfi = (screen.height - 100) / 2
		
		var marge_x_ok = (screen.width - 245) / 2
		var marge_y_ok = (screen.height - 385) / 2
		
		var marge_x_tv = (screen.width - 540) / 2
		var marge_y_tv = (screen.height - 310) / 2		
				
				
		var stilePlayerOkapi = "top=" + marge_y_ok + ", left=" + marge_x_ok + ", player, width=" + screen.width/4 + " height=" + screen.width/3.9 + ", resizable=no, menubar=no, toolbar=no, location=no, status=no, scrollbars=no";		
			
		function PopupPlayerOkapi(apri) {
			window.open(apri, "", stilePlayerOkapi);
		}		
	
	</script>	
	
</head>

<body>

	<!-------------------         INTESTAZIONE         ------------>
	<header class="clearfix">
	
		<!-------------------          MENU  ICONE MAIL FACEBOOX TWITTER           ----------->
		<nav id="top-menu" class="clearfix">			
		<nav id="top-menu" class="clearfix">			
			<ul>								
				<li><a href="#" title="Youtube">
						  <img src="images/youtube.png" alt="Youtube"></a></li>
				      <li><a href="#" title="Instagram" target="">
					      <img src="images/instagram.png" alt="Instagram"></a></li>
				      <li><a href="#" title="Twitter" target="">
					      <img src="images/twitter_ic.png" alt=""></a></li>			
				      <li><a href="#" title="Facebook" target="">
					      <img src="images/facebook_ic.png" alt=""></a></li>				
				      <li><a href="mailto:cenisudkivu@gmail.com" title="Contactez-nous" target="_blank">
					      <img src="images/email.jpg" alt=""></a></li>			
			<div id="testa">
				<nav id="main-menu" class="left navigation">
					<ul id="menusup" class="sf-menu no-bullet inline-list m0">
					 
						<li><a href="Vdossier.php?lang=fr" class="active">Retour</a></li>
							
								
					</ul>
				</nav>
			</div>
						  </ul>			
		</nav>
		
				
		<!---------------------------------          TITOLO           ----------->
		
	</header>

<div class="inner-header clearfix">
			<div id="logo" class="ads-928x90 left">
				<h1><a href=" "><img alt="" src="images/titolo"></a></h1>
			</div>			
		
		</div>

	
	<section class="container row clearfix">	

		 
	
	
	
	
		<section class="inner-container clearfix">		
			
			<!------------------------         TESTO           -------------->
			<section id="content" class="eight column row pull-left singlepost" style="min-height: 100px;">
			
				<br><br>
											
				<center>
								<h2>Espace pour valider les candidatures </h2>
								<br>
								<form id='login' action='' method='post'>
									<fieldset id="inputs">
										 <div class="control-group">
						<label class="control-label" for="country">Candidat<sup style="color: red;">*</sup></label>
						<div class="controls">
							<select id="country" name="idonline" required>
								<option value="">-</option>
								<?php 
									$req = $bd->prepare('SELECT * from candidatonline ORDER BY nomComplet' );
									$req->execute();
								while ($don = $req->fetch()) { ?>
								 
								<option value="<?php echo $don['idonline']?>"><?php echo $don['nomComplet'] ?></option>

							<?php } ?>
								
							</select>
						</div>
						<div class="control-group">
						<label class="control-label" for="country">Cironscription<sup style="color: red;">*</sup></label>
						<div class="controls">
							<select id="country" name="idCirconscription" required>
								<option value="">-</option>
								<?php 
									$req = $bd->prepare('SELECT * from circonscription ' );
									$req->execute();
								while ($don = $req->fetch()) { ?>
								 
								<option value="<?php echo $don['idCirconscription']?>"><?php echo $don['desiCirco'] ?></option>

							<?php } ?>
								
							</select>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="country">Niveau d'étude<sup style="color: red;">*</sup></label>
						<div class="controls">
							<select id="country" name="idNiveau" required>
								<option value="">-</option>
								<?php 
									$req = $bd->prepare('SELECT * from niveauEtud ' );
									$req->execute();
								while ($don = $req->fetch()) { ?>
								 
								<option value="<?php echo $don['idNiveau']?>"><?php echo $don['desiNiveau'] ?></option>

							<?php } ?>
								
							</select>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="country">Type de candidatures<sup style="color: red;">*</sup></label>
						<div class="controls">
							<select id="country" name="idTypeCandi" required>
								<option value="">-</option>
								<?php 
									$req = $bd->prepare('SELECT * from typeCandidature ' );
									$req->execute();
								while ($don = $req->fetch()) { ?>
								 
								<option value="<?php echo $don['idTypeCandi']?>"><?php echo $don['designationType'] ?></option>

							<?php } ?>
								
							</select>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="country">Type d'élection <sup style="color: red;">*</sup></label>
						<div class="controls">
							<select id="country" name="idType" required>
								<option value="">-</option>
								<?php 
									$req = $bd->prepare('SELECT * from typeElection ' );
									$req->execute();
								while ($don = $req->fetch()) { ?>
								 
								<option value="<?php echo $don['idType']?>"><?php echo $don['desiType'] ?></option>

							<?php } ?>
								
							</select>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="country">Parti politique<sup style="color: red;">*</sup></label>
						<div class="controls">
							<select id="country" name="idParti" required>
								<option value="">-</option>
								<?php 
									$req = $bd->prepare('SELECT * from partiPolitique ' );
									$req->execute();
								while ($don = $req->fetch()) { ?>
								 
								<option value="<?php echo $don['idParti']?>"><?php echo $don['sigleParti'] ?></option>

							<?php } ?>
								
							</select>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="country">Territoire<sup style="color: red;">*</sup></label>
						<div class="controls">
							<select id="country" name="idTerritoire" required>
								<option value="">-</option>
								<?php 
									$req = $bd->prepare('SELECT * from territoire ' );
									$req->execute();
								while ($don = $req->fetch()) { ?>
								 
								<option value="<?php echo $don['idTerritoire']?>"><?php echo $don['desiTerritoire'] ?></option>

							<?php } ?>
								
							</select>
						</div>
					</div>
									
									</fieldset><input style="margin-top: 0px;" type="submit" id="submit" name="enregistrer" value="Valider cette candidature">																	
										
								</form>													
							</center>						

				 				
				
			</section>
			
						
			
			
			

	 
<section class="inner-container clearfix">		
			
	<footer id="pie" class="row clearfix">
		
		<ul class="no-bullet clearfix">
		
			 
			
			<li class="widget four column">
				<h3 class="widget-title">Photos</h3>
				<div class="flickr-widget">
					<ul class="block-grid three-up">							
						<li><a href="galerie.php.html?lang=fr"><img src="images/images.jpg" alt=""></a></li>
	        		   <li><a href="galerie.php.html?lang=fr"><img src="images/hh.jpg" alt=""></a></li>
	        		   <li><a href="galerie.php.html?lang=fr"><img src="images/gggg.jpg" alt=""></a></li>
	        		   <li><a href="galerie.php.html?lang=fr"><img src="images/gg.jpg" alt=""></a></li>
	        		   <li><a href="galerie.php.html?lang=fr"><img src="images/logo_ceni_300x300_facebook.jpeg" alt=""></a></li>
					   <li><a href="galerie.php.html?lang=fr"><img src="images/band_visi.jpg" alt=""></a></li>								
												
					</ul>
				</div>
			</li>
			
			 
		</ul>
		

		<div class="copyright clearfix" style="line-height: 20px">
			© Copyright 2022 - CENI - Sud - Kivu Bukavu - Tous droits réservés			
			<br>
			Developed by 
			<a href=" " class="linkdev" target="_blank">MUNGANGA IDUMBA Ally</a>						
		</div>


		<div id="back-to-top" class="right">
			<a href="#top">Back to Top</a>
		</div>
	</footer>
	
										
			
		</section>
		
	</section>
	
		
	
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.superfish.js"></script>
	<script type="text/javascript" src="js/jquery.flexslider.min.js"></script>
	<script type="text/javascript" src="js/jquery.fancybox.js"></script>
	<script type="text/javascript" src="js/jcarousel.js"></script>
	<script type="text/javascript" src="js/jquery.masonry.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
		
	
	
	<script src="js/easy-ticker.js"></script> 
	<script type="text/javascript" src="js/jquery.js"></script>
	
	
	<!-----   SCROLLING NOTIZIE DESTRO     ---->
	
	<script>	
		/*
		$(function(){
			$('.demo1').easyTicker({
				direction: 'up',
				visible: 2,
				interval: 5000,
				controls: {
					up: '.btnUp',
					down: '.btnDown',
					toggle: '.btnToggle'
				}
			});
		});
		*/
	</script>
	
</body>

</html>
<?php
		
				if (isset ($_POST['enregistrer']))
				{
			
					
					$a=$_POST['idonline'];
					$b=$_POST['idCirconscription'];
					$c=$_POST['idNiveau'];
					$d=$_POST['idTypeCandi'];
					$e=$_POST['idType'];
					$f=$_POST['idParti'];
					$g=$_POST['idTerritoire'];
					
					 
				 
					$req = $bd->prepare("SELECT * from candidats where idonline=? ");
					$req->execute(array($a));
							if ($req->fetch()) { 
								echo "<script>alert('Tu as déjà validé  cette candidature  ')</script>";
							  }
							  
							  else{

					$req=$bd->prepare('INSERT INTO candidats (idonline,idCirconscription,idNiveau,idTypeCandi,idType,idParti,idTerritoire) VALUES(?,?,?,?,?,?,?)');
							  
						if ($req->execute(array($a,$b,$c,$d,$e,$f,$g))) 
					
						echo "<script>alert('Candidature  bien validée avec succès')</script>";
						else
						echo "<script>alert('Candidature  non  validée, récommancer encore')</script>";
					}
				
				}
			?>