<?php 

include ('include/connex.php');
session_start();

if(isset($_POST['connecter'])){
	$login = htmlentities(trim(strtolower($_POST['login'])));
	$pwd = htmlentities(trim($_POST['pwd']));



			$query1 = $bd->prepare("SELECT * FROM users WHERE login=? AND pwd=? ");
			$query1->execute(array($login, $pwd ));

				if ($done=$query1->fetch(PDO::FETCH_ASSOC)) {
								
					header('location:depot.php');
				} else {
				  	echo "<script>alert('Identifiant ou Mot de passe Incorrect')</script>";
					header('location:login.php');
				 
				}
				
		} 
		 
 ?>