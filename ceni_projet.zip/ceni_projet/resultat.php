﻿ <?php 
	
	require_once ('include/connex.php'); 
	session_start();
 ?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="description" content="La vision de la Caritas Développement Bukavu est celle d’une communauté humaine solidaire, vivant dans la paix, capable de se prendre en charge et jouissant de toute sa dignité">
	<meta name="keywords" content="CENI BUKAVU - Accueil">
		
	<title>CENI BUKAVU - Accueil</title>
		
	
	<!--FAVICON -->
	<link rel="shortcut icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">
	<link rel="icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">

	<link href='css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-1?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-2?family=Oswald:400,700' rel='stylesheet' type='text/css'>
	<link href='css-3?family=Droid+Sans' rel='stylesheet' type='text/css'>
	
	<link rel="stylesheet" type="text/css" href="css-4?family=Convergence">

	<link rel="stylesheet" href="css%20%281%29/foundation.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/responsive.css" type="text/css" media="screen">
	
	
	<script type="text/javascript">
		var marge_x_rfi = (screen.width - 245) / 2
		var marge_y_rfi = (screen.height - 100) / 2
		
		var marge_x_ok = (screen.width - 245) / 2
		var marge_y_ok = (screen.height - 385) / 2
		
		var marge_x_tv = (screen.width - 540) / 2
		var marge_y_tv = (screen.height - 310) / 2		
				
				
		var stilePlayerOkapi = "top=" + marge_y_ok + ", left=" + marge_x_ok + ", player, width=" + screen.width/4 + " height=" + screen.width/3.9 + ", resizable=no, menubar=no, toolbar=no, location=no, status=no, scrollbars=no";		
			
		function PopupPlayerOkapi(apri) {
			window.open(apri, "", stilePlayerOkapi);
		}		
	
	</script>	
	
</head>



<body>

	<!-------------------         INTESTAZIONE         ------------>
	<header class="clearfix">
	
		<!-------------------          MENU ICONE MAIL FACEBOOX TWITTER           ----------->
		<nav id="top-menu" class="clearfix">			
			<ul>								
				<li><a href="#" title="Youtube">
						  <img src="images/youtube.png" alt="Youtube"></a></li>
				      <li><a href="#" title="Instagram" target="">
					      <img src="images/instagram.png" alt="Instagram"></a></li>
				      <li><a href="#" title="Twitter" target="">
					      <img src="images/twitter_ic.png" alt=""></a></li>			
				      				
				      <li><a href="mailto:caritas_bukavu@yahoo.fr" title="Contactez-nous" target="_blank">
					      <img src="images/email.jpg" alt=""></a></li>			
						  <nav id="main-menu" class="left navigation">
					<ul id="menusup" class="sf-menu no-bullet inline-list m0">
						 
						<li><a href="login2.php" class=" ">Déconnexion</a></li>
						
								
					</ul>
					
				</nav></ul>			
		</nav>
		
				
		<!---------------------------------          TITOLO           ----------->
		<div class="inner-header clearfix">
			<div id="logo" class="ads-928x90 left">
				<h1><a href=" "><img alt="" src="images/titolo"></a></h1>
			</div>			
			
		</div>
	</header>
		
	
	
	
	<section class="container clearfix">	
	
	
		<!--------------------------------          MENU SUPERIORE           ----------->
		
		
		<section class="inner-container clearfix">		
			
			<section id="content" class="twleve  center">
			<h2>Les candidatures retenues, en cas de réclammation, veuillez nous contacter </h2>
								<br>
			
				<!-----------------------------------        SLIDESHOW                 -------------------->
				 
					 <table class="table table-bordered" >
        <thead>
            <tr class="breadcrumb">
            	
				
				<th>N°</th>
				<th>Nom de candidat</th>
				<th>Lieu et date de naissance</th>
				<th>Niveau d'étude</th>
				<th>Téléphone</th>
				<th>Circonscription</th>
				<th>Type de candidature</th>
				<th>Type d'élection</th>
				<th>Parti politique</th>
				<th>Territoire</th>
				<th>Groupement</th>
				<th>Avenue</th>
				<th>Carte d'électeur</th>
				<th>Profession</th>
				<th>Mail</th>
				
				
			</tr>
        </thead>
            <tbody>
            	<?php
            	if (isset($_POST['rechercher'])) {
            		$nomComplet = $_POST['nomEtudRech'];
				

            		$reqDep = $bdd->prepare("SELECT   * from inscriptiononline");
							
					$reqDep->execute();
            		while ($resDep = $reqDep->fetch()) { ?>
            			<tr>
                
               
							<td><?php echo $resDep['nom'] ?></td>
                            <td><?php echo $resDep['sexe']; ?></td>
							<td><?php echo $resDep['departement']; ?></td>
								
							<td><?php echo $resDep['promotion']; ?></td>
							<td><?php echo $resDep['telephone']; ?></td>
								
							<td><a target="_blank" class="text-white" href="dossierEtudiant/<?php echo $resDep['dossier'] ?>"><span class="btn btn-info ">Telecharger son dossier </span></a></td>
								
				
               
   			</tr>

            	<?php }
            }else{
            		$limit=30;
							$page = isset($_GET['page'])?$_GET['page']:1;
							$start = ($page-1)*$limit;

							$req = $bd->query("SELECT   * from candidats,candidatonline,territoire,circonscription,typeElection,typeCandidature,partiPolitique,niveauEtud where candidats.idonline=candidatonline.idonline and candidats.idNiveau=niveauEtud.idNiveau and candidats.idTerritoire=territoire.idTerritoire and candidats.idType=typeElection.idType and candidats.idTypeCandi=typeCandidature.idTypeCandi and candidats.idCirconscription=circonscription.idCirconscription  LIMIT $start,$limit");
							
							$res = $bd->query("SELECT COUNT(*) as total FROM candidats,candidatonline,territoire,circonscription,typeElection,typeCandidature,partiPolitique,niveauEtud where candidats.idonline=candidatonline.idonline and candidats.idNiveau=niveauEtud.idNiveau and candidats.idTerritoire=territoire.idTerritoire and candidats.idType=typeElection.idType and candidats.idTypeCandi=typeCandidature.idTypeCandi and candidats.idCirconscription=circonscription.idCirconscription ");

							$don1 = $res->fetch();
							$total = $don1['total'];
							$nbrePage=ceil($total/$limit);
							if ($page==1) {
								$prec = $page;
							}else {
								$prec = $page-1;
							}
							if ($page==$nbrePage) {
								$suiv =$nbrePage;	
							}
							else{
								$suiv = $page+1;
							}
		          			while($don=$req->fetch()) { ?>
            <tr>
                
							<td><?php echo $don['idCandidat'] ?></td>
							<td><?php echo $don['nomComplet'] ?></td>
							<td><?php echo $don['lieuNaissance'].',  '.$don['dateNaissance'] ?></td>
							<td><?php echo $don['desiNiveau'] ?></td>
                            <td><?php echo $don['telephone']; ?></td>
                            <td><?php echo $don['desiCirco']; ?></td>
                            <td><?php echo $don['designationType']; ?></td>
                            <td><?php echo $don['desiType']; ?></td>
                            <td><?php echo $don['desiParti']; ?></td>
                            <td><?php echo $don['desiTerritoire']; ?></td>
                            <td><?php echo $don['groupement']; ?></td>
                            <td><?php echo $don['avenue']; ?></td>
                            <td><?php echo $don['carteElecteur']; ?></td>
                            <td><?php echo $don['profession']; ?></td>
                            <td><?php echo $don['mail']; ?></td>
                            
							
               
   			</tr> <?php 
   		} 
   	} ?>
            
		</tbody>
    </table>			 
			</section>
			
 
			
			

	<!---------------------        COLONNA  DESTRA               ------------------>
			     
			</li>
		 
			
			
			


							
			
		</section>
		
	</section>
	
		
	
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.superfish.js"></script>
	<script type="text/javascript" src="js/jquery.flexslider.min.js"></script>
	<script type="text/javascript" src="js/jquery.fancybox.js"></script>
	<script type="text/javascript" src="js/jcarousel.js"></script>
	<script type="text/javascript" src="js/jquery.masonry.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
		
	
	
	<script src="js/easy-ticker.js"></script> 
	<script type="text/javascript" src="js/jquery.js"></script>
	
	
	<!-----   SCROLLING NOTIZIE DESTRO     ---->
	
	<script>	
		/*
		$(function(){
			$('.demo1').easyTicker({
				direction: 'up',
				visible: 2,
				interval: 5000,
				controls: {
					up: '.btnUp',
					down: '.btnDown',
					toggle: '.btnToggle'
				}
			});
		});
		*/
	</script>
	
</body>

</html>