<?php 
	$bd = new PDO('mysql:host=localhost;dbname=ally_db','root','');
?>