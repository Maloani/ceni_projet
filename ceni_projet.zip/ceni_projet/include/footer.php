<!-- [FOOTER]
=============================================================================================================================-->
 <footer class="footer sub-footer" >
  
          <div class="container">
            <div class="footer-info col-md-12 text-center">
              <ul>
                <li><a href="#">Adresse: Av. ATHENEE, No. 10, Q. Ndendere</a></li>
                <li><a href="#">Tél: +243 97 7408425</a></li>
                <li><a href="mailto:institutIbanda.bukavu@gmail.com">iscbukavu@gmail.com"</a></li>
              </ul>
            </div>
            
                        <div class="footer-social-icons col-md-12 text-center">
              <ul>
                <li><a target="_blank" href="http://www.twitter.com"><i class="fa fa-twitter"></i></a></li>
                <li><a target="_blank" href="http://www.facebook.com"><i class="fa fa-facebook"></i></a></li>
                <li><a target="_blank" href="http://www.google.com"><i class="fa fa-google-plus"></i></a></li>
                <li><a target="_blank" href="http://www.rss.com"><i class="fa fa-rss"></i></a></li>
              </ul>
            </div>
          </div>
    
            </footer>
 <!-- [/FOOTER]
=============================================================================================================================-->
 

</div>
 

<!-- [ /WRAPPER ]
=============================================================================================================================-->

  <!-- [ DEFAULT SCRIPT ] -->
  <script src="public/bootstrap3/library/modernizr.custom.97074.js"></script>
  <script src="public/bootstrap3/library/jquery-1.11.3.min.js"></script>
        <script src="public/bootstrap3/library/bootstrap/js/bootstrap.js"></script>
  <script type="public/bootstrap3/text/javascript" src="js/jquery.easing.1.3.js"></script>
        <script src="public/bootstrap3/library/vegas/vegas.min.js"></script>
  <!-- [ PLUGIN SCRIPT ] -->
        
  <script src="public/bootstrap3/js/plugins.js"></script>
        <script src="public/bootstrap3/js/fappear.js"></script>
       <script src="public/bootstrap3/js/jquery.countTo.js"></script>
  <script src="public/bootstrap3/js/scrollreveal.js"></script>
         <!-- [ COMMON SCRIPT ] -->
  <script src="public/bootstrap3/js/common.js"></script>



  
</body>


</html>