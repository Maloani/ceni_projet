﻿
 <?php 
	
	require_once ('include/connex.php'); 
	session_start();
 ?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="description" content="La vision de la Caritas Développement Bukavu est celle d’une communauté humaine solidaire, vivant dans la paix, capable de se prendre en charge et jouissant de toute sa dignité">
	<meta name="keywords" content="CENI BUKAVU - Accueil">
		
	<title>CENI BUKAVU - Accueil</title>
		
	
	<!--FAVICON -->
	<link rel="shortcut icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">
	<link rel="icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">

	<link href='css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-1?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-2?family=Oswald:400,700' rel='stylesheet' type='text/css'>
	<link href='css-3?family=Droid+Sans' rel='stylesheet' type='text/css'>
	
	<link rel="stylesheet" type="text/css" href="css-4?family=Convergence">

	<link rel="stylesheet" href="css%20%281%29/foundation.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/responsive.css" type="text/css" media="screen">
	
	
	<script type="text/javascript">
		var marge_x_rfi = (screen.width - 245) / 2
		var marge_y_rfi = (screen.height - 100) / 2
		
		var marge_x_ok = (screen.width - 245) / 2
		var marge_y_ok = (screen.height - 385) / 2
		
		var marge_x_tv = (screen.width - 540) / 2
		var marge_y_tv = (screen.height - 310) / 2		
				
				
		var stilePlayerOkapi = "top=" + marge_y_ok + ", left=" + marge_x_ok + ", player, width=" + screen.width/4 + " height=" + screen.width/3.9 + ", resizable=no, menubar=no, toolbar=no, location=no, status=no, scrollbars=no";		
			
		function PopupPlayerOkapi(apri) {
			window.open(apri, "", stilePlayerOkapi);
		}		
	
	</script>	
	
</head>

<body>

	<!-------------------         INTESTAZIONE         ------------>
	<header class="clearfix">
	
		<!-------------------          MENU  ICONE MAIL FACEBOOX TWITTER           ----------->
		<nav id="top-menu" class="clearfix">			
		<nav id="top-menu" class="clearfix">			
			<ul>								
				<li><a href="#" title="Youtube">
						  <img src="images/youtube.png" alt="Youtube"></a></li>
				      <li><a href="#" title="Instagram" target="">
					      <img src="images/instagram.png" alt="Instagram"></a></li>
				      <li><a href="#" title="Twitter" target="">
					      <img src="images/twitter_ic.png" alt=""></a></li>			
				      <li><a href="#" title="Facebook" target="">
					      <img src="images/facebook_ic.png" alt=""></a></li>				
				      <li><a href="mailto:cenisudkivu@gmail.com" title="Contactez-nous" target="_blank">
					      <img src="images/email.jpg" alt=""></a></li>			
			<div id="testa">
				<nav id="main-menu" class="left navigation">
					<ul id="menusup" class="sf-menu no-bullet inline-list m0">
					 
						<li><a href="login2.php?lang=fr" class="active">Deconnexion</a></li>
						<li><a href="resultat.php?lang=fr" class="active">Consulter Resultats</a></li>
								
					</ul>
				</nav>
			</div>
						  </ul>			
		</nav>
		
				
		<!---------------------------------          TITOLO           ----------->
		
	</header>
<br><br>
	

	
	<section class="container row clearfix">	

		 
	
	
	
		<section class="inner-container clearfix">		
			
			<!------------------------         TESTO           -------------->
			<section id="content" class="eight column row pull-left singlepost" style="min-height: 100px;">
			
				<br><br>
											
				<center>
				<marquee><h3>Chers candidats, avant de soumettre votre candidature, rassurez-vous que vous les avez correctement remplis et scanés afin de bien juger si vous êtes admis ou pas !!!!</marquee></h3>
							
								<h4>Espace pour soumettre les formulaires déjà remplis et scanés par le candidat</h4>
								<br>
								<?php	
								if (isset($_POST['valider'])) {
	$nomComplet = $_POST['nomComplet'];
	$telephone = $_POST['telephone'];
	$sexe = $_POST['sexe'];
	$province = $_POST['province'];
	$lieuNaissance = $_POST['lieuNaissance'];
	$dateNaissance = $_POST['dateNaissance'];
	$secteur = $_POST['secteur'];
	$groupement = $_POST['groupement'];
	$avenue = $_POST['avenue'];
	$carteElecteur = $_POST['carteElecteur'];
	$profession = $_POST['profession'];
	$mail = $_POST['mail'];
	

	$g=$_FILES['dossier']['name'];
	$g_tmp=$_FILES['dossier']['tmp_name'];
	
	
	$req = $bd->prepare('SELECT COUNT(*) AS totalN FROM candidatonline');
	
				$req->execute();
				$don = $req->fetch();
				$numMax = $don['totalN'];

        		$numAdd = $numMax + 1;
				
				$extValide = array('docx','doc','pdf','pptx','odt','xls' );
				$extentionUpload = strtolower(substr(strrchr($g, '.'), 1));
				in_array($extentionUpload, $extValide);
				$chemin = "dossierCandidature/".$numAdd.".".$extentionUpload;
				$resultat = move_uploaded_file($g_tmp, $chemin);
				$support = $numAdd.".".$extentionUpload;
				
				$req2=$bd->prepare('INSERT INTO candidatonline (nomComplet,telephone,sexe,province,lieuNaissance,dateNaissance,secteur,groupement,avenue,carteElecteur,profession,mail,dossier  )VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
					$req2->execute(array($nomComplet,$telephone,$sexe,$province,$lieuNaissance,$dateNaissance,$secteur,$groupement,$avenue,$carteElecteur,$profession,$mail,$support));	
						if ($req2) {
					
					header('Location:depot.php?sms=1');
									            
				}else{
					header('Location:depot.php?sms=2');
					
				}
	}
	if (isset($_GET['sms']) AND $_GET['sms'] == 1) { ?>
						<div class="alert alert-success alert-dismissible" id="msg" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4>Dossier bien envoyé à la CENI SUD - KIVU </h4>
						</div>
					<?php }else if (isset($_GET['sms']) AND $_GET['sms'] == 2) { ?>
						<div class="alert alert-danger alert-dismissible" id="msg" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4>Erreur d'Ajout! Vueillez vérifier le format de votre fichier (docx,doc,pdf,pptx,odt,xls)</h4>
						</div>
					<?php } 
		
?>
				<form class="form-horizontal" method="PoST" action="" enctype="multipart/form-data" >		
					<div class="control-group">
						<label class="control-label" for="inputFname1">Nom complet   <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="nomComplet" placeholder=" Nom complet " value="" required>
						</div>
					 </div>
					
					<div class="control-group">
						<label class="control-label" for="inputFname1">Téléphone  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="telephone" placeholder="Téléphone " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="country">Sexe<sup style="color: red;">*</sup></label>
						<div class="controls">
							<select id="country" name="sexe" required>
								<option value="">-</option>
								<option value="M">M</option>
								<option value="F">F</option>
								
								
							</select>
						</div>
					</div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Province  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="province" placeholder="Province d'origine " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Lieu de naissance  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="lieuNaissance" placeholder="Lieu de naissance  " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Date de naissance  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="date" id="inputFname1" name="dateNaissance" placeholder="Téléphone " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Secteur  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="secteur" placeholder="Votre secteur ou chefferie ou commune " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Groupement  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="groupement" placeholder="Groupement d'origine " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Avenue  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="avenue" placeholder="Avenue " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Carte d'électeur  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="carteElecteur" placeholder="NN d ela carte d'électeur " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Profession <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="profession" placeholder="Votre profession " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Mail  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="text" id="inputFname1" name="mail" placeholder="Mail " value="" required>
						</div>
					 </div>
					 <div class="control-group">
						<label class="control-label" for="inputFname1">Dossier  <sup style="color: red;">*</sup></label>
						<div class="controls">
						  <input type="file" id="inputFname1" name="dossier" placeholder="Date de naissance" value="" required>
						</div>
					 </div>
					
					<div class="control-group">
						<div class="controls">
							<?php if (isset($statut)) {
			  					echo '<label style="color:red">'.$statut.'</babel>';
			  				} ?>
							<br>
							<input class="btn btn-large btn-success" name="valider" type="submit" value="Je soumets ma candidature" />
						</div>
					</div>		
				</form>
			</div>
		</div>
												
							</center>						

				 				
				
			</section>
			
						
			
			
			

	 

		
	
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.superfish.js"></script>
	<script type="text/javascript" src="js/jquery.flexslider.min.js"></script>
	<script type="text/javascript" src="js/jquery.fancybox.js"></script>
	<script type="text/javascript" src="js/jcarousel.js"></script>
	<script type="text/javascript" src="js/jquery.masonry.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
		
	
	
	<script src="js/easy-ticker.js"></script> 
	<script type="text/javascript" src="js/jquery.js"></script>
	
	
	<!-----   SCROLLING NOTIZIE DESTRO     ---->
	
	<script>	
		/*
		$(function(){
			$('.demo1').easyTicker({
				direction: 'up',
				visible: 2,
				interval: 5000,
				controls: {
					up: '.btnUp',
					down: '.btnDown',
					toggle: '.btnToggle'
				}
			});
		});
		*/
	</script>
	
</body>

</html>
<?php			
			//Requette pour enregistrer les candidats 

?>	