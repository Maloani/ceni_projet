﻿<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="description" content="La vision de la Caritas Développement Bukavu est celle d’une communauté humaine solidaire, vivant dans la paix, capable de se prendre en charge et jouissant de toute sa dignité">
	<meta name="keywords" content="CENI BUKAVU - Accueil">
		
	<title>CENI BUKAVU - Accueil</title>
		
	
	<!--FAVICON -->
	<link rel="shortcut icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">
	<link rel="icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">

	<link href='css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-1?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-2?family=Oswald:400,700' rel='stylesheet' type='text/css'>
	<link href='css-3?family=Droid+Sans' rel='stylesheet' type='text/css'>
	
	<link rel="stylesheet" type="text/css" href="css-4?family=Convergence">

	<link rel="stylesheet" href="css%20%281%29/foundation.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/responsive.css" type="text/css" media="screen">
	
	
	<script type="text/javascript">
		var marge_x_rfi = (screen.width - 245) / 2
		var marge_y_rfi = (screen.height - 100) / 2
		
		var marge_x_ok = (screen.width - 245) / 2
		var marge_y_ok = (screen.height - 385) / 2
		
		var marge_x_tv = (screen.width - 540) / 2
		var marge_y_tv = (screen.height - 310) / 2		
				
				
		var stilePlayerOkapi = "top=" + marge_y_ok + ", left=" + marge_x_ok + ", player, width=" + screen.width/4 + " height=" + screen.width/3.9 + ", resizable=no, menubar=no, toolbar=no, location=no, status=no, scrollbars=no";		
			
		function PopupPlayerOkapi(apri) {
			window.open(apri, "", stilePlayerOkapi);
		}		
	
	</script>	
	
</head>



<body>

	<!-------------------         INTESTAZIONE         ------------>
	<header class="clearfix">
	
		<!-------------------          MENU ICONE MAIL FACEBOOX TWITTER           ----------->
		<nav id="top-menu" class="clearfix">			
			<ul>								
				<li><a href="#" title="Youtube">
						  <img src="images/youtube.png" alt="Youtube"></a></li>
				      <li><a href="#" title="Instagram" target="">
					      <img src="images/instagram.png" alt="Instagram"></a></li>
				      <li><a href="#" title="Twitter" target="">
					      <img src="images/twitter_ic.png" alt=""></a></li>			
				      <li><a href="#" title="Facebook" target="">
					      <img src="images/facebook_ic.png" alt=""></a></li>				
				      <li><a href="mailto:caritas_bukavu@yahoo.fr" title="Contactez-nous" target="_blank">
					      <img src="images/email.jpg" alt=""></a></li>			
						  <nav id="main-menu" class="left navigation">
					<ul id="menusup" class="sf-menu no-bullet inline-list m0">
						 
						<li><a href="" class=" ">Espace d'administration du site pour le Bureau de la CENI</a></li>
						<li><a href="Vdossier.php" class=" ">Télécharger les dossiers de candidatures</a></li>
						
								
					</ul>
					
				</nav></ul>			
		</nav>
		
				
		<!---------------------------------          TITOLO           ----------->
		<div class="inner-header clearfix">
			<div id="logo" class="ads-928x90 left">
				<h1><a href=" "><img alt="" src="images/titolo"></a></h1>
			</div>			
			
		</div>
	</header>
		
	
	
	
	<section class="container row clearfix">	
	
	
		<!--------------------------------          MENU SUPERIORE           ----------->
		<header class="clearfix">
		
			<div id="testa">
				<nav id="main-menu" class="left navigation">
					<ul id="menusup" class="sf-menu no-bullet inline-list m0">
						<li><a href="login.php?lang=fr" class="active">Déconnexion</a></li>
						<li><a href="niveau.php?lang=fr">Niveau d'étude</a></li>
						<li><a href="territoire.php?lang=fr">Territoire</a></li>
						<li><a href="circonscription.php?lang=fr">Circonscription</a></li>
						<li><a href="typeCandidature.php?lang=fr">Type candidature</a></li>						
						<li><a href="typeElection.php?lang=fr">Type élection</a></li>						
						<li><a href="partiPolitique.php?lang=fr">Parti politique</a></li>				
					</ul>
				</nav>
			</div>
			
			<div class="search-bar right clearfix">
				<a href=" " title="English"><img src="images/uk.jpg" alt="English"></a>				<a href=" " title="Italiano"><img src="images/ita.jpg" alt="Italiano"></a>				
			</div>
			
		</header>
		
			
		
		<section class="inner-container clearfix">		
			
			<section id="content" class="twleve column row pull-center">
			
			
				<!-----------------------------------        SLIDESHOW                 -------------------->
				<div class="flexslider mb25">
					<ul class="slides no-bullet inline-list m0">
						<li>
				     		<a href="#"><img alt="" src="foto/1.jpg"></a>
				     		<!--div class="flex-caption">
				                <div class="desc">
				                	<h1><a href="#"></a></h1>
				                	<p></p>
				                </div>
				            </div-->
						</li>
						  					
						<li>
							<a href="#"><img alt="" src="foto/8.jpg"></a>				     		
				   		</li>
						<li>
							<a href="#"><img alt="" src="foto/9.jpg"></a>				     		
				   		</li>						
					</ul>
				</div>
								 
			</section>
			
 
			
			

	<!---------------------        COLONNA  DESTRA               ------------------>
			     
			</li>
		 
			
			
			


	<footer id="pie" class="row clearfix">
		
		<ul class="no-bullet clearfix">
		
			 
			
			<li class="widget four column">
				<h3 class="widget-title">Photos</h3>
				<div class="flickr-widget">
					<ul class="block-grid three-up">							
						<li><a href="galerie.php.html?lang=fr"><img src="images/images.jpg" alt=""></a></li>
	        		   <li><a href="galerie.php.html?lang=fr"><img src="images/hh.jpg" alt=""></a></li>
	        		   <li><a href="galerie.php.html?lang=fr"><img src="images/gggg.jpg" alt=""></a></li>
	        		   <li><a href="galerie.php.html?lang=fr"><img src="images/gg.jpg" alt=""></a></li>
	        		   <li><a href="galerie.php.html?lang=fr"><img src="images/logo_ceni_300x300_facebook.jpeg" alt=""></a></li>
					   <li><a href="galerie.php.html?lang=fr"><img src="images/band_visi.jpg" alt=""></a></li>								
												
					</ul>
				</div>
			</li>
			
			 
		</ul>
		

		<div class="copyright clearfix" style="line-height: 20px">
			© Copyright 2022 - CENI - Sud - Kivu Bukavu - Tous droits réservés			
			<br>
			Developed by 
			<a href=" " class="linkdev" target="_blank">MUNGANGA IDUMBA Ally</a>						
		</div>


		<div id="back-to-top" class="right">
			<a href="#top">Back to Top</a>
		</div>
	</footer>
	
										
			
		</section>
		
	</section>
	
		
	
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.superfish.js"></script>
	<script type="text/javascript" src="js/jquery.flexslider.min.js"></script>
	<script type="text/javascript" src="js/jquery.fancybox.js"></script>
	<script type="text/javascript" src="js/jcarousel.js"></script>
	<script type="text/javascript" src="js/jquery.masonry.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
		
	
	
	<script src="js/easy-ticker.js"></script> 
	<script type="text/javascript" src="js/jquery.js"></script>
	
	
	<!-----   SCROLLING NOTIZIE DESTRO     ---->
	
	<script>	
		/*
		$(function(){
			$('.demo1').easyTicker({
				direction: 'up',
				visible: 2,
				interval: 5000,
				controls: {
					up: '.btnUp',
					down: '.btnDown',
					toggle: '.btnToggle'
				}
			});
		});
		*/
	</script>
	
</body>

</html>