-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 14 déc. 2022 à 06:46
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ally_db`
--
CREATE DATABASE ally_db;
USE ally_db;

-- --------------------------------------------------------

--
-- Structure de la table `bureau`
--

DROP TABLE IF EXISTS `bureau`;
CREATE TABLE IF NOT EXISTS `bureau` (
  `idBur` int(5) NOT NULL AUTO_INCREMENT,
  `nomAgent` varchar(50) NOT NULL,
  `login` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY (`idBur`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `bureau`
--

INSERT INTO `bureau` (`idBur`, `nomAgent`, `login`, `pwd`) VALUES
(1, 'MUNGANGA IDUMBA Ally', 'ally', 'ally');

-- --------------------------------------------------------

--
-- Structure de la table `candidatonline`
--

DROP TABLE IF EXISTS `candidatonline`;
CREATE TABLE IF NOT EXISTS `candidatonline` (
  `idonline` int(5) NOT NULL AUTO_INCREMENT,
  `nomComplet` varchar(50) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `sexe` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `lieuNaissance` varchar(50) NOT NULL,
  `dateNaissance` varchar(50) NOT NULL,
  `secteur` varchar(50) NOT NULL,
  `groupement` varchar(50) NOT NULL,
  `avenue` varchar(50) NOT NULL,
  `carteElecteur` varchar(50) NOT NULL,
  `profession` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `dossier` varchar(50) NOT NULL,
  PRIMARY KEY (`idonline`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `candidatonline`
--

INSERT INTO `candidatonline` (`idonline`, `nomComplet`, `telephone`, `sexe`, `province`, `lieuNaissance`, `dateNaissance`, `secteur`, `groupement`, `avenue`, `carteElecteur`, `profession`, `mail`, `dossier`) VALUES
(13, 'Maloani Saidi Georges', '0851839549', 'M', 'Sud - Kivu', 'Kibanda I', '09/01/1994', 'Bakisi', 'Bangoma', 'Pesage', '22566562203', 'Enseignant', 'georgesmaloanis@gmail.com', '2.pdf'),
(14, 'Mulongeki Amisi Paul', '0978976543', 'M', 'Nord - Kivu', 'Shabunda', '12/11/1997', 'Bakisi', 'Bamuguba - Sud', 'Pesage', '22566562203', 'Enseignant', 'louisfigo@gmail.com', '3.pdf'),
(15, 'Mutuza Kamungu Jean', '0856765321', 'M', 'Sud Ubangi', 'Kibasha', '1991-12-23', 'Nkunza', 'Ndolo', 'Lubasha', '12324567653', 'Sans', 'jeanmutuza@gmail.com', '3.pdf');

-- --------------------------------------------------------

--
-- Structure de la table `candidats`
--

DROP TABLE IF EXISTS `candidats`;
CREATE TABLE IF NOT EXISTS `candidats` (
  `idCandidat` int(5) NOT NULL AUTO_INCREMENT,
  `idonline` int(5) NOT NULL,
  `idCirconscription` int(5) NOT NULL,
  `idNiveau` int(5) NOT NULL,
  `idTypeCandi` int(5) NOT NULL,
  `idType` int(5) NOT NULL,
  `idParti` int(5) NOT NULL,
  `idTerritoire` int(5) NOT NULL,
  PRIMARY KEY (`idCandidat`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `candidats`
--

INSERT INTO `candidats` (`idCandidat`, `idonline`, `idCirconscription`, `idNiveau`, `idTypeCandi`, `idType`, `idParti`, `idTerritoire`) VALUES
(1, 13, 1, 3, 1, 1, 1, 1),
(2, 14, 1, 1, 1, 1, 1, 3);

-- --------------------------------------------------------

--
-- Structure de la table `circonscription`
--

DROP TABLE IF EXISTS `circonscription`;
CREATE TABLE IF NOT EXISTS `circonscription` (
  `idCirconscription` int(5) NOT NULL AUTO_INCREMENT,
  `desiCirco` varchar(50) NOT NULL,
  `nombreSiege` varchar(50) NOT NULL,
  `antenne` varchar(50) NOT NULL,
  `dateDepot` date NOT NULL,
  `heureDepot` time NOT NULL,
  PRIMARY KEY (`idCirconscription`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `circonscription`
--

INSERT INTO `circonscription` (`idCirconscription`, `desiCirco`, `nombreSiege`, `antenne`, `dateDepot`, `heureDepot`) VALUES
(1, 'Shabunda', '3', 'Shabunda', '2022-12-28', '16:14:00');

-- --------------------------------------------------------

--
-- Structure de la table `niveauetud`
--

DROP TABLE IF EXISTS `niveauetud`;
CREATE TABLE IF NOT EXISTS `niveauetud` (
  `idNiveau` int(5) NOT NULL AUTO_INCREMENT,
  `desiNiveau` varchar(50) NOT NULL,
  PRIMARY KEY (`idNiveau`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `niveauetud`
--

INSERT INTO `niveauetud` (`idNiveau`, `desiNiveau`) VALUES
(1, 'Gradue'),
(3, 'Licencie'),
(4, 'Master');

-- --------------------------------------------------------

--
-- Structure de la table `partipolitique`
--

DROP TABLE IF EXISTS `partipolitique`;
CREATE TABLE IF NOT EXISTS `partipolitique` (
  `idParti` int(5) NOT NULL AUTO_INCREMENT,
  `desiParti` varchar(50) NOT NULL,
  `sigleParti` varchar(50) NOT NULL,
  PRIMARY KEY (`idParti`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `partipolitique`
--

INSERT INTO `partipolitique` (`idParti`, `desiParti`, `sigleParti`) VALUES
(1, 'Union de la Nation Congolaise', 'UNC');

-- --------------------------------------------------------

--
-- Structure de la table `territoire`
--

DROP TABLE IF EXISTS `territoire`;
CREATE TABLE IF NOT EXISTS `territoire` (
  `idTerritoire` int(5) NOT NULL AUTO_INCREMENT,
  `desiTerritoire` varchar(50) NOT NULL,
  PRIMARY KEY (`idTerritoire`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `territoire`
--

INSERT INTO `territoire` (`idTerritoire`, `desiTerritoire`) VALUES
(1, 'Shabunda'),
(2, 'Mwenga'),
(3, 'Fizi'),
(4, 'Walungu'),
(5, 'Kalehe'),
(6, 'Uvira');

-- --------------------------------------------------------

--
-- Structure de la table `typecandidature`
--

DROP TABLE IF EXISTS `typecandidature`;
CREATE TABLE IF NOT EXISTS `typecandidature` (
  `idTypeCandi` int(5) NOT NULL AUTO_INCREMENT,
  `designationType` varchar(50) NOT NULL,
  PRIMARY KEY (`idTypeCandi`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `typecandidature`
--

INSERT INTO `typecandidature` (`idTypeCandi`, `designationType`) VALUES
(1, 'Titulaire');

-- --------------------------------------------------------

--
-- Structure de la table `typeelection`
--

DROP TABLE IF EXISTS `typeelection`;
CREATE TABLE IF NOT EXISTS `typeelection` (
  `idType` int(5) NOT NULL AUTO_INCREMENT,
  `desiType` varchar(50) NOT NULL,
  PRIMARY KEY (`idType`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `typeelection`
--

INSERT INTO `typeelection` (`idType`, `desiType`) VALUES
(1, 'Legislatives Nationales');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `idUser` int(5) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `login` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY (`idUser`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`idUser`, `nom`, `login`, `pwd`) VALUES
(1, 'MUPIPI Louis', 'louis', 'louis'),
(5, 'Volonte', 'vol1', '4321'),
(4, 'Ally', 'ali1', '1234'),
(6, 'Parfait', 'parf1', '1111'),
(7, 'MALOANI SAIDI Georges', 'georges', 'g1234');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
