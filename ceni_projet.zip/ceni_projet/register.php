﻿
 <?php 
	
	require_once ('include/connex.php'); 

 ?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="description" content="La vision de la Caritas Développement Bukavu est celle d’une communauté humaine solidaire, vivant dans la paix, capable de se prendre en charge et jouissant de toute sa dignité">
	<meta name="keywords" content="CENI BUKAVU - Accueil">
		
	<title>CENI BUKAVU - Accueil</title>
		
	
	<!--FAVICON -->
	<link rel="shortcut icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">
	<link rel="icon" type="image/x-icon" href="images/logo_ceni_300x300_facebook.png">

	<link href='css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-1?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
	<link href='css-2?family=Oswald:400,700' rel='stylesheet' type='text/css'>
	<link href='css-3?family=Droid+Sans' rel='stylesheet' type='text/css'>
	
	<link rel="stylesheet" type="text/css" href="css-4?family=Convergence">

	<link rel="stylesheet" href="css%20%281%29/foundation.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css%20%281%29/responsive.css" type="text/css" media="screen">
	
	
	<script type="text/javascript">
		var marge_x_rfi = (screen.width - 245) / 2
		var marge_y_rfi = (screen.height - 100) / 2
		
		var marge_x_ok = (screen.width - 245) / 2
		var marge_y_ok = (screen.height - 385) / 2
		
		var marge_x_tv = (screen.width - 540) / 2
		var marge_y_tv = (screen.height - 310) / 2		
				
				
		var stilePlayerOkapi = "top=" + marge_y_ok + ", left=" + marge_x_ok + ", player, width=" + screen.width/4 + " height=" + screen.width/3.9 + ", resizable=no, menubar=no, toolbar=no, location=no, status=no, scrollbars=no";		
			
		function PopupPlayerOkapi(apri) {
			window.open(apri, "", stilePlayerOkapi);
		}		
	
	</script>	
	
</head>



<body>

	<!-------------------         INTESTAZIONE         ------------>
	<header class="clearfix">
	
		<!-------------------          MENU ICONE MAIL FACEBOOX TWITTER           ----------->
		<nav id="top-menu" class="clearfix">			
			<ul>								
				<li><a href="#" title="Youtube">
						  <img src="images/youtube.png" alt="Youtube"></a></li>
				      <li><a href="#" title="Instagram" target="">
					      <img src="images/instagram.png" alt="Instagram"></a></li>
				      <li><a href="#" title="Twitter" target="">
					      <img src="images/twitter_ic.png" alt=""></a></li>			
				      <li><a href="#" title="Facebook" target="">
					      <img src="images/facebook_ic.png" alt=""></a></li>				
				      <li><a href="mailto:cenisudkivu@gmail.com" title="Contactez-nous" target="_blank">
					      <img src="images/email.jpg" alt=""></a></li>			
						  <div id="testa">
				<nav id="main-menu" class="left navigation">
					<ul id="menusup" class="sf-menu no-bullet inline-list m0">
						<li><a href="index.php" class="active">Accueil</a></li>
							
					</ul>
				</nav>
			</div>
						  </ul>			
		</nav>
		</br>
		
				<div id="sidebar" class="four column pull-right" style="">			
								
		<ul class="no-bullet" style="">
		
	
	</header>

	<br><br>
				<br><br>
	<section class="container row clearfix">	
		<section class="inner-container clearfix">		
			
			<!------------------------         TESTO           -------------->
			<section id="content" class="eight column row pull-left singlepost" style="min-height: 100px;">
			
				<br><br>
						
				<center>
								<marquee><h2>Espace pour s'enregistrer (Candidats)  </h2></marquee>
								<br>
								<form id='login' action='' method='post'>
									<fieldset id="inputs">
										
										<br>
										<input id="nom" name="nom" type="text" style="width: 240px;" placeholder="Entrez votre nom complet"  required="">
										<input id="login" name="login" type="text" style="width: 240px;" placeholder="Entrez votre login" required="">
										<input id="pwd" name="pwd" type="password" style="width: 240px;" placeholder="Entrez votre mot de passe" required="">
										 
									
									</fieldset><input style="margin-top: 0px;" type="submit" id="submit" name="enregistrer" value="Enregistrer">
										<a href="login2.php" style="margin-top: 0px;" class="active">J'ai déjà un compte </a></li>									
									 																
										
								</form>													
							</center>						

				 				
				
			</section>
			
		
	
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.superfish.js"></script>
	<script type="text/javascript" src="js/jquery.flexslider.min.js"></script>
	<script type="text/javascript" src="js/jquery.fancybox.js"></script>
	<script type="text/javascript" src="js/jcarousel.js"></script>
	<script type="text/javascript" src="js/jquery.masonry.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
		
	
	
	<script src="js/easy-ticker.js"></script> 
	<script type="text/javascript" src="js/jquery.js"></script>
	
	
	<!-----   SCROLLING NOTIZIE DESTRO     ---->
	
	<script>	
		/*
		$(function(){
			$('.demo1').easyTicker({
				direction: 'up',
				visible: 2,
				interval: 5000,
				controls: {
					up: '.btnUp',
					down: '.btnDown',
					toggle: '.btnToggle'
				}
			});
		});
		*/
	</script>
	
</body>

</html>
<?php
		
				if (isset ($_POST['enregistrer']))
				{
		
					$a=$_POST['nom'];
					$b=$_POST['login'];
					$c=$_POST['pwd'];
					
				 
					$req = $bd->prepare("SELECT * from users where nom=? ");
					$req->execute(array($a));
							if ($req->fetch()) { 
								echo "<script>alert('Vous vous êtes déjà enregistré, nous vous supplions uniquement de vous connecter  ')</script>";
								
							  }
							  
							  else{

					$req=$bd->prepare('INSERT INTO users (nom,login,pwd ) VALUES(?,?,?)');
							  
						if ($req->execute(array($a,$b,$c))) 
					
						echo "<script>alert('Vous êtes correctement enregistré ')</script>";
						
						else
						echo "<script>alert('Compte non  envoyé, récommancer encore')</script>";
					}
				
				}
			?>